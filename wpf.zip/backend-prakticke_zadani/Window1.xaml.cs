﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace backend_prakticke_zadani
{
    /// <summary>
    /// Interakční logika pro Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        DataSet ds = new DataSet();
        public Window1(string path)
        {
            InitializeComponent();
            ds.ReadXml(path);
            Calc();
        }
        private void Calc()
        {
            var formatInfo = new NumberFormatInfo();
            formatInfo.NumberGroupSeparator = " ";
            formatInfo.NumberDecimalSeparator = ",";

            var result = ds.Tables[0].AsEnumerable()
                .Where(row => Convert.ToDateTime(row.Field<string>("Datum_prodeje")).DayOfWeek == DayOfWeek.Saturday || Convert.ToDateTime(row.Field<string>("Datum_prodeje")).DayOfWeek == DayOfWeek.Sunday)
                .GroupBy(x => x.Field<string>("Nazev_modelu"))
                .Select(y => new { Name = y.Key, Price = y.Sum(z => Convert.ToDouble(z.Field<string>("Cena").Replace(",-","").Replace(".",""))), DPH = y.Sum(z => Convert.ToDouble(z.Field<string>("Cena").Replace(",-", "").Replace(".", "")) + (Convert.ToDouble(z.Field<string>("Cena").Replace(",-", "").Replace(".", "")) * Convert.ToDouble(z.Field<string>("DPH")) / 100)) });
            ds.Tables.Add();
            ds.Tables[1].Columns.Add("Název modelu\nCena bez DPH");
            ds.Tables[1].Columns.Add("Cena s DPH");
            foreach (var item in result)
            {
                ds.Tables[1].Rows.Add(item.Name + Environment.NewLine + (item.Price).ToString("#,0.00", formatInfo), (item.DPH).ToString("#,0.00",formatInfo));
            }
            displayTable.SetBinding(ItemsControl.ItemsSourceProperty,new Binding { Source = ds.Tables[1] });
        }
    }
}
