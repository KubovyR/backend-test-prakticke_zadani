﻿using Microsoft.Win32;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace backend_prakticke_zadani
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void searchBttn_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Filter = "XML soubory (*.xml)|*xml|Všechny soubory (*.*)|*.*";
            openFileDialog1.InitialDirectory = Directory.GetCurrentDirectory();
            openFileDialog1.ShowDialog();
            pathTextBox.Text = openFileDialog1.FileName;
        }

        private void okBttn_Click(object sender, RoutedEventArgs e)
        {
            if (File.Exists(pathTextBox.Text))
            {
                if (pathTextBox.Text.Substring(pathTextBox.Text.Length - 4) == ".xml")
                {
                    Window1 table = new Window1(pathTextBox.Text);
                    table.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Špatný typ souboru!", "Chyba", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
            else
            {
                MessageBox.Show("Soubor neexistuje!", "Chyba", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
    }
}