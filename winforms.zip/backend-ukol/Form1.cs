﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace backend_ukol
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void searchBttn_Click(object sender, EventArgs e)
        {
            openFileDialog1.InitialDirectory = Directory.GetCurrentDirectory();
            openFileDialog1.ShowDialog();
            pathTextBox.Text = openFileDialog1.FileName;
        }

        private void okBttn_Click(object sender, EventArgs e)
        {
            if(File.Exists(pathTextBox.Text))
            {
                if (pathTextBox.Text.Substring(pathTextBox.Text.Length-4) == ".xml")
                {
                    using(Form2 table = new Form2(pathTextBox.Text))
                    {
                        table.ShowDialog(this);
                    }
                }
                else
                {
                    MessageBox.Show("Špatný typ souboru!", "Chyba", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Soubor neexistuje!", "Chyba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
